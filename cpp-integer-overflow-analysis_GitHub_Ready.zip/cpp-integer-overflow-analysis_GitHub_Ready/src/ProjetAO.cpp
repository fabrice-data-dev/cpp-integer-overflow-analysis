
// ProjetAO.cpp : Ce fichier contient la fonction 'main'. L'exécution du programme commence et se termine à cet endroit.
//
#define _CRT_SECURE_NO_WARNINGS
#include <math.h>
//#include <limts.h>
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include "stdafx.h"

void addMultSINT();
void FonctionEpsfEpsd();
void FonctionSomfSomd();
void FonctionSomadfSomadd();

void clearStdinBuffer();
short lireShortValidationETConversion();

void FonctionEpsfEpsd();


int main()
{
    char rep= 'y';
	char menu = 'A';

	printf("--------------------------------------------------------------\n");

	printf("\n Faite le choix du menu selon l'ordre suivante: tapez la lettre:\n");
	printf("'A' pour acceder a la function 'addMultSINT()'\n");
	printf("'B' pour acceder a la function 'FonctionEpsfEpsd()'\n");
	printf("'C' pour acceder a la function 'FonctionSomfSomd()' \n");
	printf("'D' pour acceder a la function 'FonctionSomadfSomadd()': \n\n");

	scanf("%c", &menu);
	clearStdinBuffer();

	while (menu != 'A' && menu != 'B' && menu != 'C' && menu != 'D')
	{
		printf("\n Faite le choix du menu selon l'ordre suivante: tapez la lettre:\n");
		printf("'A' pour acceder a la function 'addMultSINT()'\n");
		printf("'B' pour acceder a la function 'FonctionEpsfEpsd()'\n");
		printf("'C' pour acceder a la function 'FonctionSomfSomd()' \n");
		printf("'D' pour acceder a la function 'FonctionSomadfSomadd()': \n\n");

		scanf("%c", &menu);
		clearStdinBuffer();
	}

	if (menu == 'A') {

		printf("\n fonction devra afficher le résultat de la somme et de la multiplication et \n");
		printf("indiquer si ces résultats sont corrects ou sont  un débordement de capacité, positif ou négatif \n");
		printf("  ************************************************************************************************** \n\n");
		while (rep == 'y')
		{
			addMultSINT();
			printf("\n\n voulez-vous verifier la somme et le produit de 2 shorts (y) ?");
			scanf("%c", &rep);
			clearStdinBuffer();


		}
		return 0;
	}

	else if (menu == 'B') {
		printf("\n Fonctions qui évaluent l’epsilon de l’architecture INTEL ainsi que le nombre de chiffres binaires significatifs de la partie fractionnaire\n");
		printf("  ************************************************************************************************** \n\n");
		FonctionEpsfEpsd();
		return 0;
	}

	else if (menu == 'C') {
		printf("\n -------- Fonction qui implémente deux fonctions qui calculent la sommation successive de 1/n pour n itérations  --------------- \n");
		printf("  ****************************************************************************************************************- \n\n");
		FonctionSomfSomd();
		return 0;
	}

	else if (menu == 'D') {
		printf("\n ------------ Fonction qui iplemente la sommation ascendante et descendante d'une fonction sommeascf() qui permet de faire la sommation ascendante et sommedescf() pour la sommation descendante \n");
		printf("\t de nombres réels SP et sommeascd() et sommedescd() dans le cas de nombres réels DP -------------- \n");
		printf("  *******************************************************************************************************- \n\n");
		FonctionSomadfSomadd();
		return 0;
	}
	
	return 0;
  
}


/*++++++++++++++++++++++++++++++++++ EXERCICE 1 ++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

/* Cette fonction devra afficher le résultat de la somme et de la multiplication et
indiquer si ces résultats sont corrects ou sont  un débordement de capacité, positif ou négatif.*/

/*---------------------------------------------------------------------------------*/
void addMultSINT() {

	// declaration des variables d'entree et les variables sommes et multiplicateur
	short int n1, n2, som, mult;
	int testmult;
	// variable pour validation ou pas et de debordement positif ou negatif
	int nbValide = 0;

	printf("veuillez entrer une première valeur short \n ");
	n1 = lireShortValidationETConversion();
	
	printf("veuillez entrer une deuxième valeur short \n ");
	n2 = lireShortValidationETConversion();

	som = n1 + n2;
	mult = n1 * n2;
	testmult = n1 * n2;


	// combinaison en fonction des resultats pour n1 > 0 et n2 > 0 ou n2 > 0 et n1 > 0
	/******************************************************************************/

	
	if ( n1 > 0 && n2 > 0) {

		// Debordement positif pour la somme et du produit
		if (som < 0 && testmult > 32767) {
		printf("\n debordement positif pour la somme");
		printf("\n resultat invalide de: %d + %d = %d\n", n1, n2, som);
		
		printf("\n debordement positif pour le produit");
		printf("\n resultat invalide du produit: %d * %d = %d", n1, n2, mult);
		}
		// resultat valide
		else if (som <= 32767 && testmult <= 32767) {
			printf("\n resultat valide de la somme: %d + %d = %d\n", n1, n2, som);
			printf("\n resultat valide du produit: %d * %d = %d", n1, n2, mult);
		}

		// Debordement positif pour le produit
		else if (som <= 32767 && testmult > 32767) {

			printf("\n resultat valide de la somme: %d + %d = %d\n", n1, n2, som);

			printf("\n debordement positif pour le produit");
			printf("\n resultat invalide du produit: %d * %d = %d", n1, n2, mult);
		}

		// Debordement positif pour la somme
		else if (n1 > 0 && n2 > 0 && som < 0 && testmult <= 32767) {
			printf("\n debordement positif pour la somme");
			printf("\n resultat invalide de la somme: %d + %d = %d\n", n1, n2, som);

			printf("\n resultat valide du produit: %d * %d = %d", n1, n2, mult);
		}
	}


	/******************************************************************************/


	// combinaison en fonction des resultats pour n1 < 0 et n2 < 0 ou n2 < 0 et n1 < 0
	/******************************************************************************/
	// resultat valide
	if ( n1 < 0 && n2 < 0) {

		// resultat valide
		if (som >= -32767 && testmult <= 32767) {

			printf("\n resultat valide de la somme: %d + %d = %d\n", n1, n2, som);
			printf("\n resultat valide du produit: %d * %d = %d", n1, n2, mult);
		}

		// Debordement negatif de la somme et positif du produit
		else if (som >= 0 && testmult > 32767) {

			printf("\n debordement negatif pour la somme");
			printf("\n resultat invalide de: %d + %d = %d\n", n1, n2, som);

			printf("\n debordement positif pour le produit");
			printf("\n resultat invalide du produit: %d * %d = %d", n1, n2, mult);
		}

		// Debordement  positif du produit
		else if (som >= -32767 && testmult > 32767) {

			printf("\n resultat valide de la somme: %d + %d = %d\n", n1, n2, som);

			printf("\n debordement positif pour le produit");
			printf("\n resultat invalide du produit: %d * %d = %d", n1, n2, mult);
		}

		// Debordement  Negatif de la somme
		else if (som >=0  && testmult <= 32767) {

			printf("\n debordement negatif pour la somme");
			printf("\n resultat invalide de: %d + %d = %d\n", n1, n2, som);

			printf("\n resultat valide du produit: %d * %d = %d", n1, n2, mult);
		}
	}

	/******************************************************************************/


	// combinaison en fonction des resultats pour n1 < 0 et n2 > 0 ou n2 < 0 et n1 > 0
	/******************************************************************************/
	
	if ((n1 < 0 && n2 > 0) ||(n2 < 0 && n1 > 0)) {
		if (som >= -32767 && testmult >= -32767) {// resultat valide
		printf("\n resultat valide de la somme: %d + %d = %d\n", n1, n2, som);
		printf("\n resultat valide du produit: %d * %d = %d", n1, n2, mult);
	    }
		else if (som >= -32767 && testmult < -32765) {// Debordement  negatif du produit
			printf("\n resultat valide de la somme: %d + %d = %d\n", n1, n2, som);

			printf("\n debordement negatif pour la produit");
			printf("\n resultat invalide du produit: %d * %d = %d", n1, n2, mult);
		}
	}
	
	
	
	/******************************************************************************/
	
	
}
/*---------------------------------------------------------------------------------*/


/* Titre: lireShortValidationETConversion
Description : permet d'introduire un nombre entier short (-32768, 32767) au clavier
en faire la conversion et en faire la validation

INPUT : aucun
OUTPUT : valeur entiere short convertie

*/
/*---------------------------------------------------------------------------------*/
short lireShortValidationETConversion()
{
	char chaineAconvertir[100];
	int i, imin, nbCar = 0;
	int retVal = 0;
	int valide = 0;
	int chiffre = 0;
	int negatif = 0;
	int positif = 0;

	while (!valide)
	{
		negatif = 0;
		positif = 0;
		retVal = 0;

		//clearStdinBuffer();

		printf("Introduire une valeur entiere entre -2^15 et (2^15) - 1:");

		if (fgets(chaineAconvertir, sizeof(chaineAconvertir), stdin) != NULL)
		{
			nbCar = strlen(chaineAconvertir);

			if (chaineAconvertir[0] == '-')
				negatif = 1;
			if (chaineAconvertir[0] == '+')
				positif = 1;

			if (nbCar <= 7) // nombre decimal trop grand
			{
				i = nbCar - 2;
				if (negatif || positif)
					imin = 1;
				else
					imin = 0;
				while (i >= imin)
				{
					if (chaineAconvertir[i] >= '0' && chaineAconvertir[i] <= '9')
					{
						chiffre = chaineAconvertir[i] - '0';
						retVal += chiffre * int(pow(10.0, nbCar - i - 2));
						if ((negatif && (retVal > (SHRT_MAX + 1))) || (!negatif && (retVal > SHRT_MAX)))
						{
							i = 0;
							valide = 0;
							retVal = 0;
						}
						else
						{
							valide = 1;
						}
					}
					else
					{
						i = 0;
						valide = 0;
						retVal = 0;
					}
					i--;
				}
			}

		}
	}
	if (!negatif)
		return(retVal);
	else
		return(-retVal);
}

void clearStdinBuffer()
{
	char c;
	//while (getchar() != '\n')
	//while ((c = getchar()) != '\n' && c != EOF) { }
	while ((c = getchar()) != '\n' && c != '\r') {}

}

/*---------------------------------------------------------------------------------*/
/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

/*++++++++++++++++++++++++++++++++++ EXERCICE 2 ++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/





//fonction pour evaluer l'epsilon d'un float de l’architecture INTEL ainsi que le nombre de chiffres binaires significatifs de la partie fractionnaire

void epsilonf() {

	//creation de la variable qui va nous servir pour stocker la valeur de epsilon
	float epsf = 1; 
	//creation et initialisation de notre compteur pour determiner le nombre de bit significatif
	int i = 0;     
	printf("\n ------------ la fonction qui affiche epsilon pour une representation des relles virgule flottantes precision est  et le nombre de bit significatif ------------------ \n\n");
	
	/*
		ici la boucle va continuer a tourner jusqu'a ce qu'elle rencontre
		 une valeur de eps pour laquelle 1 + eps = 1
		 et bien entendu nous allons successivement incrementer le i qui nous sert de compteur
	*/
	while ((1 + epsf) != 1) {
		epsf = epsf / 2;
		printf("le epsilon pour une representation en float est %e et le nombre de bit significatif est %d \n", epsf, i);
		i++;
	}
	

}



//fonction pour evaluer l'epsilon d'un double de l’architecture INTEL ainsi que le nombre de chiffres binaires significatifs de la partie fractionnaire
void epsilond() {
	double epsd = 1;
	int i = 0;
	printf("\n ------------ la fonction qui affiche epsilon pour une representation des relles double precision est  et le nombre de bit significatif ------------------ \n\n");
	
	while ((1 + epsd) != 1) {
		epsd = epsd / 2;
		printf("le epsilon pour une representation des relles double precision est %le et le nombre de bit significatif est %d\n", epsd, i);
		i++;
	}
	

}

/*-------------------------------------------------------------------------------------------------*/

/* Les deux fonctions qui évaluent l’epsilon de l’architecture INTEL ainsi que le nombre de
chiffres binaires significatifs de la partie fractionnaire.  */
/*-------------------------------------------------------------------------------------------------*/
void FonctionEpsfEpsd() {

	
	epsilonf();
	epsilond();

}
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/





/*++++++++++++++++++++++++++++++++++ EXERCICE 3 ++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/



/* Fonction qui implémente une fonction reel en virgule flottant qui calcule la sommation successive de 1/n pour n itérations.
Le nombre de termes additionnés (n) devrait être un multiple de 100 (soit 100, 1000, ou 10000) que vous
demandez à l’utilisateur et dont vous devez faire la validation.   */

float sommef(int n) {
	float somf = 0;
	float errorf;
	printf("\n ------------ Fonction qui implémente une fonction reel en virgule flottant qui calcule la sommation successive de 1/n pour n itérations------------------ \n\n");
	
	printf("saisissez le nombre d'iteration entre (100, 1000 et 10000) \n");
	scanf("%d", &n);

	/*
		cette boucle verifie l'entree de l'utilisateur
		si elle n'est pas valide elle va lui demander d'entrer une nouvelle valeur et ainsi de suite
	*/
	if (n != 100 && n != 1000 && n != 10000) {
		do {
			printf("! nombre invalide ! \n veillez  SVP entrer un nombre entre (100, 1000 et 10000) \n");
			scanf("%d", &n);
		} while (n != 100 && n != 1000 && n != 10000);

	}
	printf("nombre valide vous avez entrez %d \n", n);
	/*
		ici on fait la somme des 1/n
	*/
	for (int i = 1; i <= n;i++) {
		somf += 1.0 / i;
	}

	/*
		###Calcule de l'erreur#######
		Mathematique parlant quand on fait la fonction de 1/n nfois, on obtient log(n)+Y
		Y representant la constance d'Eucler qui est sensiblemet egale a 0.5772156649
		pour determiner l'erreur de calcule nous allons chercher la valeur absolue de
		la difference entre la somme de 1/n et log(n) sur un formatage a 10 chiffres apres la virgule
	*/

	//    #fabsf() est une fonction de la bibliotheque math.h en C qui permet de calculer la valeur absolue

	errorf = fabsf(somf - log(n));

	printf("La somme des 1/n \t pour n= %d iterations est %.10f et l'erreur est %.10f \n", n, somf, errorf);
	return somf;
}

/* Fonction qui implémente une fonction reel en double qui calcule la sommation successive de 1/n pour n itérations.
Le nombre de termes additionnés (n) devrait être un multiple de 100 (soit 100, 1000, ou 10000) que vous
demandez à l’utilisateur et dont vous devez faire la validation.   */

double sommed(int n) {
	double somd = 0;
	double errord;

	printf("\n ------------ Fonction qui implémente une fonction reel en double qui calcule la sommation successive de 1/n pour n itérations  ------------------ \n\n");
	

	printf("Cas des flottant double precisions saisissez le nombre d'iteration entre (100, 1000 et 10000) \n");
	scanf("%d", &n);

	if (n != 100 && n != 1000 && n != 10000) {
		do {
			printf("!!!!nombre invalide !!!! \n veillez  SVP entrer un nombre entre (100;1000 et 10000) \n");
			scanf("%d", &n);
		} while (n != 100 && n != 1000 && n != 10000);

	}
	printf("nombre valide vous avez entrez %d \n", n);

	for (int i = 1; i <= n;i++) {
		somd += 1.0 / i;
	}

	errord = fabsf(somd - log(n));

	printf("La somme des 1/n \t pour n= %d iterations est %.10f et l'erreur est %.10f \n", n, somd, errord);
	return somd;
}


/* Fonction qui implémente deux fonctions qui calculent la sommation successive de 1/n pour n itérations.
Le nombre de termes additionnés (n) devrait être un multiple de 100 (soit 100, 1000, ou 10000) que vous
demandez à l’utilisateur et dont vous devez faire la validation.   */

/*-------------------------------------------------------------------------------------------------*/


void FonctionSomfSomd() {
	
	int nfd=2;

		sommef(nfd);
	
		sommed(nfd);

}
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/


/*++++++++++++++++++++++++++++++++++ EXERCICE 4 ++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/


/* Fonctions qui iplemente la sommation descendante et ascendente du cas des reels simple precision */
/*----------------------------------------------------------------------------------------------------------*/
 /* Fonction qui iplemente la sommation ascendante cas des reels simple precision */

void sommeascf() {
	float somaf = 0.0;
	int i, j;
	int n = 1;

	/*
		Pour calculer la somme ici nous avons utilisez deux boucle imbriquees for
		la premier c'est une boucle qui parcours les exposants n (de 1 a 3) et dans cette boucle la,
		nous avons une seconde boucle qui permer de parcourir la base i de 1 a 32767
		puis nous avons utilise la fonction pow(i,n) de la lib math.h qui retourne la valeur de i exp(n);
	*/

	printf("\n ------------ Fonction qui iplemente la sommation ascendante cas des reels simple precision  ----------------- \n\n\n");
	
	printf("\t\t\t\t----------- CAS DES SIMPLES PRECISIONS ---------\n");
	printf("-------------- SOMME ASCENDANTE ---------------\n");

	for (j = 1; j <= 3; j++) {
		printf("pour n=%d \t", n);
		for (i = 1; i <= 32767;i++) {
			somaf += 1.0 / (powf(i, n));
		}
		n++;
		printf("la somme est :%.10f \n", somaf);
	}

}


/* Fonction qui iplemente la sommation descendante cas des reels simple precision */
void sommedescf() {
	float somdf = 0.0;
	int i, j;
	int n = 1;

	printf("\n ------------ Fonction qui iplemente la sommation descendante cas des reels simple precision  ------------- \n\n\n");
	

	printf("\t\t\t\t----------- CAS DES SIMPLES PRECISIONS ---------\n");
	printf("----------- SOMME DESCENDANTE -------------\n");

	for (j = 1; j <= 3; j++) {
		printf("pour n=%d \t", n);
		for (i = 32767; i >= 1;i--) {
			somdf += 1.0 / (powf(i, n));
		}
		n++;
		printf("la somme est :%.10f \n", somdf);

	}

}

/*----------------------------------------------------------------------------------------------------------*/
/* Fonctions qui iplemente la sommation descendante et ascendente du cas des double simple precision */
/*----------------------------------------------------------------------------------------------------------*/


/* Fonctions qui iplemente la sommation ascendente du cas des double simple precision */
void sommeascd() {
	double somad = 0.0;
	int n = 1;

	printf("\n ------------ Fonctions qui iplemente la sommation ascendente du cas des double simple precision  ----------- \n\n\n");
	

	printf("\t\t\t\t--------- CAS DES DOUBLES PRECISIONS -------------\n");
	printf("------------- SOMME ASCENDANTE ---------------\n");
	for (int j = 1; j <= 3; j++) {
		printf("pour n=%d \t", n);
		for (int i = 1; i <= 32767;i++) {
			somad += 1.0 / (powf(i, n));
		}
		n++;
		printf("la somme est :%.10lf \n", somad);
	}

}


/* Fonctions qui iplemente la sommation ascendente du cas des double simple precision */
void sommedescd() {
	double somdd = 0.0;
	int n = 1;

	printf("\n ------------ Fonctions qui iplemente la sommation ascendente du cas des double simple precision  ---------------- \n\n\n");
	

	printf("\t\t\t\t--------- CAS DES DOUBLES PRECISIONS -------------\n");
	printf("------------ SOMME DESCENDANTE -------------\n");
	for (int j = 1; j <= 3; j++) {
		printf("pour n=%d \t", n);
		for (int i = 32767; i >= 1;i--) {
			somdd += 1.0 / (pow(i, n));
		}
		n++;
		printf("la somme est :%.10lf \n", somdd);
	}

}

/* Fonction qui iplemente la sommation ascendante et descendante d'une fonction sommeascf() qui permet de faire la sommation
ascendante et  sommedescf() pour la sommation descendante de nombres réels SP.
qui implemente aussi les fonctions sommeascd() et sommedescd() dans le cas de nombres réels DP.
La suite additionnée est:  (1/in) pour i allant de 1 à 32767 dans le cas ascendant et de 32767 à 1 dans le cas descendant.    */

void FonctionSomadfSomadd() {
	
		sommeascf();
		sommedescf();
		sommeascd();
		sommedescd();


}

/*----------------------------------------------------------------------------------------------------------*/
/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
